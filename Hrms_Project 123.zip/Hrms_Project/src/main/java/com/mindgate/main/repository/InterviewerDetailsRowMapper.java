package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.domain.InterviewerDetails;

public class InterviewerDetailsRowMapper implements RowMapper<InterviewerDetails> {

	public InterviewerDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		int interviewId = rs.getInt("interview_Id");
		ApplicantDetails applicantDetails = new ApplicantDetails();
		applicantDetails.setApplicantId(rs.getInt("applicant_Id"));
		EmployeeDetails employeeDetails = new EmployeeDetails();
		employeeDetails.setEmployeeId(rs.getInt("employee_Id"));
		String status = rs.getString("status");
		int round1 = rs.getInt("round_1");
		int round2 = rs.getInt("round_2");
		int round3 = rs.getInt("round_3");
		InterviewerDetails interviewerDetails = new InterviewerDetails(interviewId, applicantDetails, employeeDetails,
				status, round1, round2, round3);
		return interviewerDetails;
	}
}
