package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.domain.InterviewerDetails;

public interface InterviewerDetailsServiceInterface {

	
	public boolean addInterviewerDetails(InterviewerDetails interviewerDetails);
	
	public List<InterviewerDetails> getInterviewerDetailst(int employee_id);
	
	public boolean updateInterviewerDetails(InterviewerDetails interviewerDetails);

	public InterviewerDetails getInterviewObject(int interviewId);

}
