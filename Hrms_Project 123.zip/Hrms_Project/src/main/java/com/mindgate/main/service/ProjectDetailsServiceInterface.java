package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.domain.ProjectDetails;

public interface ProjectDetailsServiceInterface {

	public List<ProjectDetails> viewBudget(int projectId);

}